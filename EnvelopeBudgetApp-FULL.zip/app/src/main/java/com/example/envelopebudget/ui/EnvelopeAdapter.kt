package com.example.envelopebudget.ui
import android.view.*
import android.widget.*
import androidx.recyclerview.widget.RecyclerView
import com.example.envelopebudget.*
import com.example.envelopebudget.data.EnvelopeEntity

class EnvelopeAdapter(val inc:(EnvelopeEntity)->Unit,val exp:(EnvelopeEntity)->Unit)
:RecyclerView.Adapter<EnvelopeAdapter.VH>(){
 private var list=listOf<EnvelopeEntity>()
 fun submitList(l:List<EnvelopeEntity>){list=l;notifyDataSetChanged()}
 class VH(v:View):RecyclerView.ViewHolder(v){
  val n:TextView=v.findViewById(R.id.txtName)
  val b:TextView=v.findViewById(R.id.txtBalance)
  val i:Button=v.findViewById(R.id.btnIncome)
  val e:Button=v.findViewById(R.id.btnExpense)
 }
 override fun onCreateViewHolder(p:ViewGroup,v:Int)=VH(LayoutInflater.from(p.context)
  .inflate(R.layout.item_envelope,p,false))
 override fun onBindViewHolder(h:VH,i:Int){
  val e=list[i]
  h.n.text=e.name
  h.b.text="₹${e.balance}"
  h.i.setOnClickListener{inc(e)}
  h.e.setOnClickListener{exp(e)}
 }
 override fun getItemCount()=list.size
}
