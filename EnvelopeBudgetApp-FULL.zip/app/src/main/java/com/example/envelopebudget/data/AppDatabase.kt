package com.example.envelopebudget.data
import android.content.Context
import androidx.room.*
@Database(entities=[EnvelopeEntity::class],version=1)
abstract class AppDatabase:RoomDatabase(){
 abstract fun envelopeDao():EnvelopeDao
 companion object{
  @Volatile private var I:AppDatabase?=null
  fun getDatabase(c:Context)= I?: synchronized(this){
   Room.databaseBuilder(c.applicationContext,AppDatabase::class.java,"env.db").build().also{I=it}
  }
 }
}
