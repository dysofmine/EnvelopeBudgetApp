package com.example.envelopebudget
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.viewModels
import androidx.recyclerview.widget.*
import com.example.envelopebudget.ui.EnvelopeAdapter

class MainActivity : ComponentActivity() {
 private val vm: EnvelopeViewModel by viewModels()
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  setContentView(R.layout.activity_main)
  val rv = findViewById<RecyclerView>(R.id.recyclerView)
  val ad = EnvelopeAdapter({ vm.addIncome(it,100.0) },{ vm.addExpense(it,50.0) })
  rv.layoutManager = LinearLayoutManager(this)
  rv.adapter = ad
  vm.envelopes.observe(this){ ad.submitList(it) }
  vm.addEnvelope("Food",1000.0)
 }
}
