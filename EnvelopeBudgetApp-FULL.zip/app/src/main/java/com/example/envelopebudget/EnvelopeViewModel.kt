package com.example.envelopebudget
import android.app.Application
import androidx.lifecycle.*
import com.example.envelopebudget.data.*
import kotlinx.coroutines.launch

class EnvelopeViewModel(app:Application):AndroidViewModel(app){
 private val db=AppDatabase.getDatabase(app)
 val envelopes=db.envelopeDao().getAllEnvelopes()
 fun addEnvelope(n:String,b:Double)=viewModelScope.launch{
  db.envelopeDao().insertEnvelope(EnvelopeEntity(name=n,balance=b))
 }
 fun addIncome(e:EnvelopeEntity,a:Double)=viewModelScope.launch{
  db.envelopeDao().updateEnvelope(e.copy(balance=e.balance+a))
 }
 fun addExpense(e:EnvelopeEntity,a:Double)=viewModelScope.launch{
  db.envelopeDao().updateEnvelope(e.copy(balance=e.balance-a))
 }
}
