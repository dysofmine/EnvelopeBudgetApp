package com.example.envelopebudget.data
import androidx.room.*
@Entity(tableName="envelopes")
data class EnvelopeEntity(
 @PrimaryKey(autoGenerate=true) val id:Int=0,
 val name:String,
 val balance:Double
)
