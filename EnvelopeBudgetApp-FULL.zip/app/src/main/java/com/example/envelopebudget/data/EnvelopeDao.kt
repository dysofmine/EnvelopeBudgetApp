package com.example.envelopebudget.data
import androidx.lifecycle.LiveData
import androidx.room.*
@Dao
interface EnvelopeDao{
 @Query("SELECT * FROM envelopes") fun getAllEnvelopes():LiveData<List<EnvelopeEntity>>
 @Insert suspend fun insertEnvelope(e:EnvelopeEntity)
 @Update suspend fun updateEnvelope(e:EnvelopeEntity)
}
